// Datos de acordes (simplificado)
const chordDatabase = {
    "C": ["01023X", "35553X", "889AA8", "31023X"],
    "Cm": ["31343X", "888AA8", "3134XX"],
    "C7": ["01013X", "35353X", "888A88"],
    "D": ["000232", "5757XX", "AACFXF"],
    "Dm": ["000231", "5756XX", "AABFXF"],
    "E": ["022100", "4446XX", "999BCC"],
    "Em": ["022000", "4445XX", "999ABB"],
    "F": ["112331", "5557XX", "AAA0CC"],
    "Fm": ["111331", "5556XX", "AAA0BB"],
    "G": ["320003", "7779XX", "CCC0EE"],
    "Gm": ["310033", "7778XX", "CCC0DD"],
    "A": ["002220", "5777XX", "AAA0CC"],
    "Am": ["002210", "5776XX", "AAA0BB"],
    "B": ["224442", "7999XX", "BBB0DD"],
    "Bm": ["223442", "7998XX", "BBB0CC"]
};

// Variables de estado
let currentRoot = "C";
let currentType = "M";
let currentNotation = "latin"; // 'latin' o 'english'
let currentPosition = 0;
let leftyMode = false;

// Elementos del DOM
const chordNameEl = document.getElementById('chord-name');
const diagramContainerEl = document.querySelector('.diagram-container');
const positionIndicatorEl = document.getElementById('position-indicator');
const prevButton = document.getElementById('prev-chord');
const nextButton = document.getElementById('next-chord');
const notationButton = document.getElementById('toggle-notation');
const leftyButton = document.getElementById('toggle-lefty');
const noteElements = document.querySelectorAll('.note');
const typeElements = document.querySelectorAll('.type');

// Inicialización
document.addEventListener('DOMContentLoaded', () => {
    loadChord();
    setupEventListeners();
});

function setupEventListeners() {
    // Navegación de acordes
    prevButton.addEventListener('click', () => {
        if (currentPosition > 0) {
            currentPosition--;
            updateDiagramPosition();
        }
    });
    
    nextButton.addEventListener('click', () => {
        const chord = getCurrentChord();
        if (currentPosition < chord.positions.length - 1) {
            currentPosition++;
            updateDiagramPosition();
        }
    });
    
    // Cambiar notación
    notationButton.addEventListener('click', toggleNotation);
    
    // Modo zurdo
    leftyButton.addEventListener('click', toggleLefty);
    
    // Selectores de notas y tipos
    noteElements.forEach(el => {
        el.addEventListener('click', () => {
            noteElements.forEach(n => n.classList.remove('selected'));
            el.classList.add('selected');
            currentRoot = el.textContent;
            currentPosition = 0;
            loadChord();
        });
    });
    
    typeElements.forEach(el => {
        el.addEventListener('click', () => {
            typeElements.forEach(t => t.classList.remove('selected'));
            el.classList.add('selected');
            currentType = el.textContent;
            currentPosition = 0;
            loadChord();
        });
    });
}

function getCurrentChord() {
    const chordKey = currentRoot + (currentType === "M" ? "" : currentType);
    const positions = chordDatabase[chordKey] || ["000000"];
    return { name: chordKey, positions };
}

function loadChord() {
    const chord = getCurrentChord();
    
    // Actualizar nombre del acorde
    chordNameEl.textContent = currentNotation === "latin" ? 
        translateToLatin(chord.name) : chord.name;
    
    // Limpiar diagramas existentes
    diagramContainerEl.innerHTML = '';
    positionIndicatorEl.innerHTML = '';
    
    // Crear nuevos diagramas
    chord.positions.forEach((pos, index) => {
        // Diagrama
        const diagramEl = document.createElement('div');
        diagramEl.className = 'chord-diagram';
        diagramEl.dataset.position = pos;
        diagramContainerEl.appendChild(diagramEl);
        
        // Puntos del diagrama
        renderDiagram(diagramEl, pos);
        
        // Indicador de posición
        const dotEl = document.createElement('div');
        dotEl.className = 'position-dot';
        if (index === currentPosition) dotEl.classList.add('active');
        positionIndicatorEl.appendChild(dotEl);
    });
    
    // Posicionar el diagrama correcto
    updateDiagramPosition();
}

function renderDiagram(container, position) {
    if (position === "000000") {
        container.innerHTML = '<div style="font-size: 48px; text-align: center; line-height: 150px;">?</div>';
        return;
    }
    
    // Implementación simplificada del diagrama
    for (let i = 0; i < 6; i++) {
        const stringPos = position[i];
        if (stringPos === 'X') {
            // Cuerda no tocada
            const xEl = document.createElement('div');
            xEl.textContent = 'X';
            xEl.style.position = 'absolute';
            xEl.style.left = `${10 + i * 20}px`;
            xEl.style.top = '10px';
            container.appendChild(xEl);
        } else if (stringPos !== '0') {
            // Traste pisado
            const fret = parseInt(stringPos, 16);
            const circleEl = document.createElement('div');
            circleEl.textContent = '•';
            circleEl.style.position = 'absolute';
            circleEl.style.left = `${10 + i * 20}px`;
            circleEl.style.top = `${10 + (fret - 1) * 30}px`;
            circleEl.style.fontSize = '24px';
            container.appendChild(circleEl);
        }
        // Cuerda al aire no necesita marcador
    }
}

function updateDiagramPosition() {
    const containerWidth = diagramContainerEl.clientWidth;
    diagramContainerEl.style.transform = `translateX(-${currentPosition * containerWidth}px)`;
    
    // Actualizar indicadores de posición
    const dots = positionIndicatorEl.querySelectorAll('.position-dot');
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === currentPosition);
    });
}

function toggleNotation() {
    currentNotation = currentNotation === "latin" ? "english" : "latin";
    notationButton.textContent = currentNotation === "latin" ? "C D E" : "DO RE MI";
    loadChord();
}

function toggleLefty() {
    leftyMode = !leftyMode;
    leftyButton.style.backgroundColor = leftyMode ? "#f84" : "";
    leftyButton.style.color = leftyMode ? "white" : "";
    loadChord();
}

// Funciones de traducción
function translateToLatin(chord) {
    const translations = {
        'C': 'DO', 'D': 'RE', 'E': 'MI', 'F': 'FA', 'G': 'SOL', 'A': 'LA', 'B': 'SI',
        'C#': 'DO#', 'D#': 'RE#', 'F#': 'FA#', 'G#': 'SOL#', 'A#': 'LA#',
        'Db': 'REb', 'Eb': 'MIb', 'Gb': 'SOLb', 'Ab': 'LAb', 'Bb': 'SIb'
    };
    
    // Extraer la nota base y el tipo
    const rootMatch = chord.match(/^[A-G][#b]?/);
    if (!rootMatch) return chord;
    
    const root = rootMatch[0];
    const type = chord.slice(root.length);
    
    return (translations[root] || root) + type;
}

function translateToEnglish(chord) {
    const translations = {
        'DO': 'C', 'RE': 'D', 'MI': 'E', 'FA': 'F', 'SOL': 'G', 'LA': 'A', 'SI': 'B',
        'DO#': 'C#', 'RE#': 'D#', 'FA#': 'F#', 'SOL#': 'G#', 'LA#': 'A#',
        'REb': 'Db', 'MIb': 'Eb', 'SOLb': 'Gb', 'LAb': 'Ab', 'SIb': 'Bb'
    };
    
    // Extraer la nota base y el tipo
    const rootMatch = chord.match(/^[A-Z][a-z#b]?/);
    if (!rootMatch) return chord;
    
    const root = rootMatch[0];
    const type = chord.slice(root.length);
    
    return (translations[root] || root) + type;
}