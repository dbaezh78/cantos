// generate-index.js
const fs = require('fs');
const path = require('path');

const cantos = [];

// Leer todos los JS en /cjs
fs.readdirSync('./cjs').forEach(archivo => {
    if (archivo.endsWith('.js')) {
        try {
            const filePath = path.join('./cjs', archivo);
            const contenido = require(filePath);
            const p = contenido.partitura;
            
            cantos.push({
                id: archivo.replace('.js', ''),
                titulo: p.titulo,
                salmo: p.salmo || '',
                letra: [...p.cantor, ...p.asamblea].join(' ').toLowerCase(),
                archivo: `../${archivo.replace('.js', '.html')}` // Ruta relativa
            });
        } catch (error) {
            console.error(`Error en ${archivo}:`, error);
        }
    }
});

// Guardar en /find (crea la carpeta si no existe)
if (!fs.existsSync('./find')) fs.mkdirSync('./find');
fs.writeFileSync('./find/index.json', JSON.stringify(cantos, null, 2));
console.log(`Índice generado con ${cantos.length} cantos en /find/index.json`);